# Toggle Title Menu * CSS Only

A Pen created on CodePen.io. Original URL: [https://codepen.io/TheMOZZARELLA/pen/gOePxaN](https://codepen.io/TheMOZZARELLA/pen/gOePxaN).

Click the welcome title to expand the element into a responsive icon menu. Try clicking/tapping the buttons, and resizing. The --gradient variable will change all the colors at once.