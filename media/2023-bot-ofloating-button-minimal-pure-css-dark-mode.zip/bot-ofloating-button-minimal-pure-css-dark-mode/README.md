# Botão - Floating Button minimal / Pure CSS / Dark Mode

A Pen created on CodePen.io. Original URL: [https://codepen.io/visions/pen/gOxjELJ](https://codepen.io/visions/pen/gOxjELJ).

