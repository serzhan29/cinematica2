# Vertical menu with gooey effect on hover

A Pen created on CodePen.io. Original URL: [https://codepen.io/onediv/pen/WNOdMWw](https://codepen.io/onediv/pen/WNOdMWw).

A vertical menu with gooey effect on hover.